importScripts('areas.js','match-engine.js','storage.js');
const CRM='https://dsiqke8d1w5q2zz5.github.io/jijdspwl3115djsjlp/01-crm/';
const FIELDS=['areaCity','areaOther','areaCities','areaDists','areaDisplay','roomTypes','budgetMin','budgetMax','budget','want','noWant','matchCriteria'];
let working=false,starting=false,continuing=false;
const delay=ms=>new Promise(r=>setTimeout(r,ms));
// Local aggregate timings only: no listing URLs, names, addresses or input values.
const searchMetrics={since:new Date().toISOString(),stages:{},tabsCreated:0,tabsReused:0};let metricFlushAt=0,metricFlight;
let metricBase;
async function flushSearchMetrics(force=false){
 if(metricFlight){await metricFlight;if(!force)return;}
 if(!force&&Date.now()-metricFlushAt<30000)return;metricFlushAt=Date.now();
 metricFlight=Promise.resolve().then(async()=>{
  if(!metricBase)metricBase=(await BuyerStorage.get('searchPerformance')).searchPerformance||{};
  const count=n=>Number.isFinite(n)&&n>=0?n:0,stages={};
  for(const data of [metricBase.stages,searchMetrics.stages])for(const [key,v]of Object.entries(data||{})){
   if(!/^(navigation|read|details|page|save|report|encode|request|requestWait):(591|sinyi|yungching|local)$/.test(key))continue;
   const m=stages[key]||(stages[key]={count:0,totalMs:0,maxMs:0,failed:0});
   for(const k of ['count','totalMs','failed'])m[k]+=count(v[k]);m.maxMs=Math.max(m.maxMs,count(v.maxMs));
  }
  const snapshot={since:Number.isFinite(Date.parse(metricBase.since))?metricBase.since:searchMetrics.since,updatedAt:new Date().toISOString(),stages,tabsCreated:count(metricBase.tabsCreated)+searchMetrics.tabsCreated,tabsReused:count(metricBase.tabsReused)+searchMetrics.tabsReused};
  await BuyerStorage.set({searchPerformance:snapshot});
 }).catch(()=>{}).finally(()=>metricFlight=null);return metricFlight;
}
function noteSearchMetric(stage,source,start,ok=true){const key=stage+':'+(['591','sinyi','yungching'].includes(source)?source:'local'),elapsed=Math.max(0,Date.now()-start),m=searchMetrics.stages[key]||(searchMetrics.stages[key]={count:0,totalMs:0,maxMs:0,failed:0});m.count++;m.totalMs+=elapsed;m.maxMs=Math.max(m.maxMs,elapsed);if(!ok)m.failed++;void flushSearchMetrics();}
async function timedSearch(stage,source,work){const at=Date.now();let ok=false;try{const value=await work();ok=true;return value;}finally{noteSearchMetric(stage,source,at,ok);}}
function timedSearchSync(stage,work){const at=Date.now();let ok=false;try{const value=work();ok=true;return value;}finally{noteSearchMetric(stage,'local',at,ok);}}
let searchTabs=null,lastCRMActivity=-Infinity;
function searchConcurrency(){return Date.now()-lastCRMActivity<8000?1:2;}
async function forgetSearchTab(entry){const key='ownedTab_'+entry.source,saved=await BuyerStorage.get(key);if(saved[key]===entry.id)await BuyerStorage.remove(key);}
async function acquireSearchTab(url,source,control){
 if(!searchTabs){const tab=await chrome.tabs.create({url,active:false});searchMetrics.tabsCreated++;return tab;}
 let entry=searchTabs.find(e=>!e.busy&&e.source===source)||searchTabs.find(e=>!e.busy);
 if(entry){const current=await chrome.tabs.get(entry.id).catch(()=>null);if(!current||current.active||!current.url||!['buy.yungching.com.tw','www.sinyi.com.tw','sale.591.com.tw','business.591.com.tw'].includes(new URL(current.url).hostname)){searchTabs.splice(searchTabs.indexOf(entry),1);await forgetSearchTab(entry);entry=null;}}
 if(entry){entry.busy=true;await forgetSearchTab(entry);const prior=await chrome.scripting.executeScript({target:{tabId:entry.id},func:()=>true,args:[]}).catch(()=>[]);control.previousDocumentId=prior[0]?.documentId;await chrome.tabs.update(entry.id,{url,active:false});entry.source=source;searchMetrics.tabsReused++;}
 else{const tab=await chrome.tabs.create({url,active:false});entry={id:tab.id,source,busy:true};searchTabs.push(entry);searchMetrics.tabsCreated++;}
 control.poolEntry=entry;return {id:entry.id};
}
async function releaseSearchTab(tab,task,control,completed){const entry=control.poolEntry;if(entry&&completed&&!control.expired&&searchTabs?.includes(entry)){entry.busy=false;return;}if(tab?.id)await chrome.tabs.remove(tab.id).catch(()=>{});if(entry&&searchTabs?.includes(entry))searchTabs.splice(searchTabs.indexOf(entry),1);const key='ownedTab_'+task.source,owned=await BuyerStorage.get(key);if(owned[key]===tab?.id)await BuyerStorage.remove(key);}
async function closeSearchTabs(){const pool=searchTabs;searchTabs=null;for(const entry of pool||[]){const tab=await chrome.tabs.get(entry.id).catch(()=>null);if(tab&&!tab.active&&tab.url&&['buy.yungching.com.tw','www.sinyi.com.tw','sale.591.com.tw','business.591.com.tw'].includes(new URL(tab.url).hostname))await chrome.tabs.remove(entry.id).catch(()=>{});await forgetSearchTab(entry);}}

function cleanDemands(ds){if(!Array.isArray(ds)||!ds.length)throw Error('請先填寫買方需求');return ds.map(raw=>{const d=BuyerMatchEngine.normalizeDemand(raw);return Object.fromEntries(FIELDS.filter(k=>d[k]!==undefined).map(k=>[k,d[k]]));});}
// Only verified native filters are sent; preferences remain local ranking criteria.
function tasksFor(ds){const tasks=new Map(),valid=v=>/^\d+(?:\.\d+)?$/.test(String(v??''))?String(v):'';
 for(const d of ds){const m=d.matchCriteria||{},required=label=>!m.optional?.includes(label),words=required('社區／路段')?[...new Set(String(m.keywords||'').split(/[,，、\n]/).map(x=>x.trim()).filter(Boolean))]:[];
 const lo=valid(d.budgetMin),hi=valid(d.budgetMax),amin=required('建坪')&&m.areaBasis!=='main'?valid(m.areaMin):'',amax=required('建坪')&&m.areaBasis!=='main'?valid(m.areaMax):'',fmin=required('樓層')?valid(m.floorMin):'',fmax=required('樓層')?valid(m.floorMax):'',age=required('屋齡')?valid(m.ageMax):'';
 const areas=CRM_AREAS.filter(a=>(!d.areaCities?.length||d.areaCities.includes(a.city))&&(!d.areaDists?.length||d.areaDists.includes(a.district)));
 for(const a of areas)for(const word of words.length?words:['']){const yc=[encodeURIComponent(a.city+'-'+a.district)+'_c'],sy=[a.sinyi,a.zip+'-zip'],u=new URL('https://sale.591.com.tw/?shType=list&regionid='+a.region);
 if(lo||hi){yc.push(lo+'-'+hi+'_price');sy.push((lo||'min')+'-'+(hi||'up')+'-price');if(lo&&hi)u.searchParams.set('price',lo+'_'+hi);}
 if(amin||amax){yc.push(amin+'-'+amax+'_pin');sy.push((amin||'min')+'-'+(amax||'up')+'-area');}
 if(fmin||fmax){yc.push(fmin+'-'+fmax+'_fr');sy.push((fmin||'min')+'-'+(fmax||'up')+'-floor');if(fmin&&fmax)u.searchParams.set('floor',fmin+'_'+fmax);}
 if(m.exclude?.includes('presale'))sy.push('resale');
 if(age){yc.push('-'+age+'_age');sy.push('0-'+age+'-year');}
 // Usage labels (shop/office/mixed use) may describe an apartment too. Check locally after retrieval.
 if(word){yc.push(encodeURIComponent(word)+'_kw');sy.push(encodeURIComponent(word)+'-keyword');u.searchParams.set('keywords',word);}
 const urls={yungching:'https://buy.yungching.com.tw/list/'+yc.join('/'),sinyi:'https://www.sinyi.com.tw/buy/list/'+sy.join('/')+'/default-desc/1','591':u.href};
 const purpose=m.searchPurpose||'',commercialKinds=({住宅:[],店面:[5],辦公:[6],廠房:[7],倉庫:[7],住商混合:[5,6,7,12]})[purpose]||[5,6,7,12];if(['店面','辦公','廠房','倉庫'].includes(purpose))delete urls['591'];const entries=Object.entries(urls);for(const kind of commercialKinds){const commercial=new URL('https://business.591.com.tw/list');commercial.searchParams.set('type','2');commercial.searchParams.set('region',a.region);commercial.searchParams.set('kind',kind);if(word)commercial.searchParams.set('keywords',word);entries.push(['591',commercial.href]);}for(const [source,url]of entries){const key=source+':'+a.city+':'+a.district+':'+url;tasks.set(key,{key,source,url,city:a.city,district:a.district,keyword:word,demands:[...(tasks.get(key)?.demands||[]),d],first:true,visited:[],lastIds:[]});}}
 }return [...tasks.values()];}
function filterTaskRows(rows,task){const norm=v=>String(v||'').normalize('NFKC').trim().replaceAll('臺','台');return rows.filter(p=>!BuyerMatchEngine.isParkingOnly(p)&&(!p.city||norm(p.city)===norm(task.city))&&(!p.district||norm(p.district)===norm(task.district)));}
async function waitReadable(tabId,requireComplete=false,previousDocumentId){
 for(let i=0;i<140;i++){
  const tab=await chrome.tabs.get(tabId);if(tab.status==='complete'&&!previousDocumentId)return;
  try{
   // A slow image/advertisement must not block an already parsed search document.
   // Match the current tab URL so a previous page/about:blank cannot pass readiness.
   const result=await chrome.scripting.executeScript({target:{tabId},func:expected=>document.readyState!=='loading'&&!!document.body&&/^https?:$/.test(location.protocol)&&(!expected||location.href===expected),args:[tab.url||'']});
   if(result[0]?.result===true&&(!previousDocumentId||result[0].documentId!==previousDocumentId))return;
  }catch{}
  await delay(250);
 }
 throw Error('網頁主要內容載入逾時，未視為完成');
}

async function pageRows(task,control={}){let tab,completed=false;const pageAt=Date.now();try{if(task.source==='591')await check591Cooldown();const regionURL=new URL(task.url),cacheKey=regionURL.hostname+'|'+(regionURL.searchParams.get('regionid')||regionURL.searchParams.get('region'))+'|'+task.district,cache=(await BuyerStorage.get('sectionCache')).sectionCache||{};const cached=task.source==='591'&&task.first&&cache[cacheKey];if(cached)regionURL.searchParams.set('section',cached);const navigationAt=Date.now();tab=await acquireSearchTab(regionURL.href,task.source,control);control.tabId=tab.id;if(control.expired)throw Error("搜尋逾時");await saveSearch({['ownedTab_'+task.source]:tab.id});await waitReadable(tab.id,task.source==='591',control.previousDocumentId);noteSearchMetric('navigation',task.source,navigationAt);if(task.source==='591'&&task.first){let chosen=false;for(let i=0;i<12;i++){const r=await chrome.scripting.executeScript({target:{tabId:tab.id},func:district=>{const button=[...document.querySelectorAll('button.section,label.t5-checkbox')].find(e=>(e.querySelector('.t5-checkbox__text')?.textContent||e.textContent).trim()===district);if(!button)return false;const groups=[...document.querySelectorAll('button.section')];const candidates=groups.length?groups:[...document.querySelectorAll('label.t5-checkbox')];const extra=candidates.find(e=>e!==button&&e.querySelector('input')?.checked);if(extra){extra.click();return false;}const checkbox=button.querySelector('input');if(!checkbox?.checked){button.click();return false;}return new URL(location.href).searchParams.has('section');},args:[task.district]});if(r[0]?.result){chosen=true;break;}await delay(1500);}if(!chosen)throw Error('591 行政區篩選未確認，沒有改抓整個縣市');const selected=await chrome.tabs.get(tab.id);if(!new URL(selected.url).searchParams.has('section'))throw Error('591 區域網址未確認');const section=new URL(selected.url).searchParams.get('section');await saveSearch({sectionCache:{...cache,[cacheKey]:section}});if(!cached||cached!==section){await chrome.tabs.update(tab.id,{url:selected.url});await waitReadable(tab.id,task.source==='591');}}
 await chrome.scripting.executeScript({target:{tabId:tab.id},files:task.source==='591'?['acorn.js','read591.js','read.js','pagination.js']:['read.js','pagination.js']});let lastRead;for(let i=0;i<12;i++){const readAt=Date.now();const result=await chrome.scripting.executeScript({target:{tabId:tab.id},func:(source,city)=>globalThis.crmReadPage(source,city),args:[task.source,task.city]});const data=result[0]?.result;noteSearchMetric('read',task.source,readAt);lastRead=data;if(data?.blocked)throw Error('原站拒絕讀取或要求驗證');if(data&&(data.rows?.length||data.complete)&&(data.page||data.complete)){const value=await timedSearch('details',task.source,()=>task.source==='591'?enrich591(tab.id,data,task,control):['sinyi','yungching'].includes(task.source)?enrichSinyi(tab.id,data,task,control):data);completed=true;return value;}await delay(1500);}throw Error(lastRead?.page&&!lastRead?.rows?.length?'頁面有分頁，但未讀取到刊登資料；未視為完成':lastRead?.rows?.length?'已讀到刊登，但無法確認下一頁或末頁；未視為完成':'未讀到刊登，也未確認原站零筆結果；未視為完成');}finally{noteSearchMetric('page',task.source,pageAt,completed);await releaseSearchTab(tab,task,control,completed);}}
// Each listing gets at most two detail requests per search job, persisted across worker restarts.
async function enrichSinyi(tabId,data,task,control={}){
 const roundKey='detailRound_'+task.source,cacheKey='searchDetails_'+task.source,saved=await BuyerStorage.get([roundKey,cacheKey]),cache=saved[roundKey]===task.roundId?(saved[cacheKey]||{}):{};
 const rows=filterTaskRows(data.rows||[],task).filter(p=>((/^sinyi:[A-Za-z0-9]+$/.test(p.id||'')&&p.url==='https://www.sinyi.com.tw/buy/house/'+p.id.slice(6))||(/^yungching:\d+$/.test(p.id||'')&&p.url==='https://buy.yungching.com.tw/house/'+p.id.slice(10)))&&(task.demands||[]).some(d=>BuyerMatchEngine.evaluate(d,p).status!=='excluded'));
 const wanted=[...new Map(rows.map(p=>[p.id,p])).values()].filter(p=>!cache[p.id]);
 for(let offset=0;offset<wanted.length;offset+=3){
 if(control.expired)throw Error('搜尋已中止');
 const batch=wanted.slice(offset,offset+3);
 // Reserve before network work. An interrupted worker must not create an unlimited retry loop.
 for(const p of batch)cache[p.id]={detailStatus:'failed',detailAttemptedAt:new Date().toISOString(),detailError:'補讀中斷，請在下一次手動搜尋重試',detailAttempts:2};
 if(batch.length){
 await saveSearch({[roundKey]:task.roundId,[cacheKey]:cache});
 try{const result=await chrome.scripting.executeScript({target:{tabId},func:async rows=>{
 const out={};let i=0;await Promise.all([0,1].map(async()=>{while(i<rows.length){const row=rows[i++];
 for(let attempt=1;attempt<=2;attempt++){const at=new Date().toISOString();try{
 const r=await fetch(row.url,{signal:AbortSignal.timeout(6000)});let value;
 if([404,410].includes(r.status))value={availability:'unavailable',availabilityReason:'原物件頁已失效（HTTP '+r.status+'）'};
 else {if(!r.ok)throw Error('HTTP '+r.status);const doc=new DOMParser().parseFromString(await r.text(),'text/html');value=row.id.startsWith('yungching:')?globalThis.crmReadYCDetail(doc):globalThis.crmReadSinyiDetail(doc,row.id.slice(6));if(value.availability!=='unavailable'&&!value.usage&&!value.buildingType&&!value.mainArea)throw Error('詳細頁未取得可核對欄位');}
 out[row.id]={...value,detailStatus:'ok',detailAttemptedAt:at,detailCheckedAt:at,detailError:'',detailAttempts:attempt};break;
 }catch(e){out[row.id]={detailStatus:'failed',detailAttemptedAt:at,detailAttempts:attempt,detailError:e.name==='TimeoutError'||e.name==='AbortError'?'詳細頁讀取逾時':String(e.message||'詳細頁讀取失敗').slice(0,160)};if(attempt===1)await new Promise(r=>setTimeout(r,500));}
 }
 }}));return out;},args:[batch.map(p=>({id:p.id,url:p.url}))]});Object.assign(cache,result[0]?.result||{});
 }catch(e){for(const p of batch)cache[p.id].detailError='補讀程序未完成：'+String(e.message||e).slice(0,120);}
 await saveSearch({[roundKey]:task.roundId,[cacheKey]:cache});
 if(control.expired)throw Error('搜尋已中止');
 await control.progress?.();
 }
 }
 data.rows=data.rows.map(p=>({...p,...cache[p.id]}));return data;
}
// Only the currently verified IDs in an assistant-owned tab may use this transport.
let verify591Queue=Promise.resolve();
const detail591Sessions=new Map();
async function detail591Request(message,sender){
 const session=detail591Sessions.get(sender.tab?.id);
 if(!session||sender.id!==chrome.runtime.id||sender.frameId!==0||!/^https:\/\/(sale|business)\.591\.com\.tw\//.test(sender.url||''))throw Error('未授權的詳細資料請求');
 if(!session.urls.has(message.url))throw Error('詳細資料網址不在本次核對範圍');
 if(session.busy)throw Error('詳細資料請求尚未完成');
 session.busy=true;
 try{
  const rate=session.rate;if(rate.until>Date.now())return {error:'591 暫時限流，請等候冷卻後再重試',name:'RateLimitError',retryAt:rate.until};
  const waitAt=Date.now();await delay(Math.max(0,(rate.nextAt||0)-Date.now()));noteSearchMetric('requestWait','591',waitAt);
  if(detail591Sessions.get(sender.tab.id)!==session)throw Error('核對已停止');
  rate.nextAt=Date.now()+1500;
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),6000);
  const at=Date.now();let ok=false;
  try{
   const response=await fetch(message.url,{cache:'no-store',credentials:'include',signal:controller.signal});
   if(response.status===429){const h=response.headers.get('Retry-After')||'',ms=/^\d+$/.test(h.trim())?Number(h)*1000:Date.parse(h)-Date.now();rate.until=Date.now()+Math.max(60000,Number.isFinite(ms)?ms:0);rate.nextAt=rate.until;return {error:'591 暫時限流，請等候冷卻後再重試',name:'RateLimitError',retryAt:rate.until};}
   const text=await response.text();if(text.length>8*1024*1024)throw Error('詳細資料回應過大');
   ok=response.ok;return {status:response.status,ok:response.ok,url:response.url,text};
  }catch(e){return {error:controller.signal.aborted?'原物件頁讀取逾時':String(e.message||e),name:controller.signal.aborted?'TimeoutError':'Error'};}
  finally{clearTimeout(timer);noteSearchMetric('request','591',at,ok);await saveSearch({detail591Rate:rate});}
 }finally{session.busy=false;}
}
function verify591Rows(tabId,rows){
 const run=verify591Queue.catch(()=>{}).then(async()=>{
  const {detail591Rate={nextAt:0,until:0}}=await BuyerStorage.get('detail591Rate');
  const urls=new Set();for(const p of rows){if(!/^591:\d+$/.test(p.id)||p.url!=='https://sale.591.com.tw/home/house/detail/2/'+p.id.slice(4)+'.html')throw Error('詳細資料網址不符');urls.add(p.url);urls.add('https://bff-house.591.com.tw/v1/web/sale/detail?id='+p.id.slice(4));}
  detail591Sessions.set(tabId,{urls,rate:detail591Rate,busy:false});
  try{
   const result=await chrome.scripting.executeScript({target:{tabId},func:async(rows,rate)=>{globalThis.crm591Rate=rate;globalThis.crm591WorkerTransport=true;try{const checks=await globalThis.crmVerifyListings(rows.map(p=>({...p,source:'591'})));return {checks,rate:globalThis.crm591Rate};}finally{globalThis.crm591WorkerTransport=false;}},args:[rows,detail591Rate]});
   const value=result[0]?.result;if(!value?.checks)throw Error('原物件核對未回傳結果');return value.checks;
  }finally{const session=detail591Sessions.get(tabId);detail591Sessions.delete(tabId);await saveSearch({detail591Rate:session?.rate||detail591Rate});await flushSearchMetrics(true);}
 });verify591Queue=run;return run;
}
async function check591Cooldown(){const {detail591Rate}=await BuyerStorage.get('detail591Rate');if(detail591Rate?.until>Date.now())throw Error('591 暫時限流，請於 '+new Date(detail591Rate.until).toLocaleTimeString('zh-TW',{timeZone:'Asia/Taipei'})+' 後重試未完成範圍');}
async function enrich591(tabId,data,task,control={}){
 const savedDetails=await BuyerStorage.get(['detailCache','detailCacheRound']),detailCache=task.roundId&&savedDetails.detailCacheRound===task.roundId?(savedDetails.detailCache||{}):{},now=Date.now();const candidates=filterTaskRows(data.rows||[],task).filter(p=>/https:\/\/sale\.591\.com\.tw\/home\/house\/detail\/2\/\d+\.html$/.test(p.url||'')&&(task.demands||[]).some(d=>BuyerMatchEngine.evaluate(d,p).status!=='excluded'));
 const wanted=[...new Map(candidates.map(p=>[p.id,p])).values()].filter(p=>!Object.hasOwn(detailCache,p.id));
 // Save small batches so completed checks survive an interrupted page.
 for(let offset=0;offset<wanted.length;offset+=3){
  if(control.expired)throw Error('搜尋已中止');
  if(task.roundId&&control.progress){const {job}=await BuyerStorage.get('job');if(job?.id!==task.roundId||job.status!=='running')throw Error('搜尋已取消或已更換');}
  const batch=wanted.slice(offset,offset+3);
  for(const p of batch)detailCache[p.id]={at:now,detailVersion:2,availability:'unknown',detailStatus:'failed',detailError:'補讀中斷，請重新搜尋'};
  await saveSearch({detailCache,detailCacheRound:task.roundId||null});
  try{const checks=await verify591Rows(tabId,batch.map(p=>({id:p.id,url:p.url})));for(const value of checks)detailCache[value.id]={...value,detailVersion:2,at:now};}
  catch(e){for(const p of batch)detailCache[p.id]={...detailCache[p.id],detailAttemptedAt:new Date().toISOString(),detailError:'補讀程序未完成：'+String(e.message||e).slice(0,120)};}
  if(control.expired)throw Error('搜尋已中止');
  await saveSearch({detailCache:Object.fromEntries(Object.entries(detailCache).sort((a,b)=>b[1].at-a[1].at).slice(0,5000)),detailCacheRound:task.roundId||null});
  await control.progress?.();
 }
 data.rows=data.rows.map(p=>{const v=detailCache[p.id];return v&&v.detailVersion===2?{...p,...v}:p;});return data;
}
// Reuse only identical successful requests within the same search job. Failures remain retryable.
let requestRound='',requestMemo=new Map();
async function readWithDeadline(task){if(!task.roundId)return readPageDeadline(task);if(requestRound!==task.roundId){requestRound=task.roundId;requestMemo=new Map();}const memo=requestMemo,key=JSON.stringify([task.source,task.city,task.district,task.url,!!task.first,task.demands||[]]);if(!memo.has(key)){const work=readPageDeadline(task).catch(error=>{memo.delete(key);throw error;});memo.set(key,work);if(memo.size>100)memo.delete(memo.keys().next().value);}return structuredClone(await memo.get(key));}
async function readPageDeadline(task){
 const control={};let timer,finished=false,rejectDeadline;
 const arm=()=>{clearTimeout(timer);timer=setTimeout(()=>{control.expired=true;if(control.tabId)chrome.tabs.remove(control.tabId).catch(()=>{});rejectDeadline(Error('連續 2 分鐘沒有處理進度，已停止此搜尋組合'));},120000);};
 control.progress=async()=>{
  if(finished||control.expired)return;
  arm();
  // Never overwrite the scheduler's full job while another source is completing.
  const saved=await BuyerStorage.get(['jobProgress','dailyProgress']),values={},at=new Date().toISOString();
  for(const key of ['jobProgress','dailyProgress'])if(saved[key]?.id===task.roundId&&saved[key].status==='running')values[key]={...saved[key],lastProgressAt:at};
  if(Object.keys(values).length)await BuyerStorage.set(values);
 };
 const deadline=new Promise((_,reject)=>{rejectDeadline=reject;arm();});
 try{return await Promise.race([pageRows(task,control),deadline]);}finally{finished=true;clearTimeout(timer);}
}
async function buyerVerify(payload){const rows=payload?.rows;if(!Array.isArray(rows)||rows.length>3)throw Error('每次最多核對3筆');const checks=[];for(const source of ['591','yungching','sinyi']){const group=rows.filter(p=>p.source===source&&((source==='591'&&/^591:\d+$/.test(p.id)&&p.url==='https://sale.591.com.tw/home/house/detail/2/'+p.id.slice(4)+'.html')||(source==='yungching'&&/^yungching:\d+$/.test(p.id)&&p.url==='https://buy.yungching.com.tw/house/'+p.id.slice(10))||(source==='sinyi'&&/^sinyi:[A-Za-z0-9]+$/.test(p.id)&&p.url==='https://www.sinyi.com.tw/buy/house/'+p.id.slice(6))));if(!group.length)continue;if(source==='591')await check591Cooldown();let tab;try{tab=await chrome.tabs.create({url:source==='591'?'https://sale.591.com.tw/':source==='sinyi'?'https://www.sinyi.com.tw/buy/':'https://buy.yungching.com.tw/',active:false});await waitReadable(tab.id,false);await chrome.scripting.executeScript({target:{tabId:tab.id},files:['read591.js','read.js']});if(source==='591')checks.push(...await verify591Rows(tab.id,group));else {const result=await chrome.scripting.executeScript({target:{tabId:tab.id},func:rows=>globalThis.crmVerifyListings(rows),args:[group]});checks.push(...(result[0]?.result||[]));}}finally{if(tab?.id)await chrome.tabs.remove(tab.id).catch(()=>{});}}return {checks};}
async function inventoryVerify(payload){
 const rows=payload?.rows;if(!Array.isArray(rows)||rows.length>3)throw Error('每次最多核對3筆');
 return {checks:await Promise.all(rows.map(async p=>{
  const u=new URL(p.url);const valid=u.protocol==='https:'&&!u.username&&!u.password&&({yungching:u.hostname==='buy.yungching.com.tw'&&/^\/house\//.test(u.pathname),sinyi:u.hostname==='www.sinyi.com.tw'&&/^\/buy\/house\//.test(u.pathname),'591':((u.hostname==='sale.591.com.tw'&&/^\/home\/house\/detail\//.test(u.pathname))||(u.hostname==='business.591.com.tw'&&/^\/sale\/\d+$/.test(u.pathname)))}[p.source]);
  if(!valid)return {id:p.id,status:'unknown'};
  let tab;try{tab=await chrome.tabs.create({url:u.href,active:false});await waitReadable(tab.id,true);const result=await chrome.scripting.executeScript({target:{tabId:tab.id},func:expected=>{
   if(location.href.split('?')[0]!==expected.split('?')[0])return 'unknown';
   const text=document.body?.innerText||'';if(/驗證碼|存取遭拒|Access Denied|captcha/i.test(text))return 'unknown';
   return /您查詢的物件不存在，可能已關閉或者被刪除|您所查詢的物件已下架|此物件已下架|此房屋已下架|此房源已下架|物件已停止銷售/.test(text)?'off':'unknown';
  },args:[u.href]});return {id:p.id,status:result[0]?.result||'unknown'};}catch{return {id:p.id,status:'unknown'};}finally{if(tab?.id)await chrome.tabs.remove(tab.id).catch(()=>{});}
 }))};
}

function dailyProgressOf(job){return job?{id:job.id,detailRetry:job.detailRetry?{done:job.detailRetry.done,total:job.detailRetry.total}:null,status:job.status,startedAt:job.initialStartedAt||job.startedAt,lastProgressAt:job.lastProgressAt,pages:job.pages||0,doneScopes:job.doneScopes||0,totalScopes:job.totalScopes||0,finishedAt:job.finishedAt||null,active:(job.active||[]).map(x=>({source:x.source,district:x.district})),day:job.dailyDay||localDate(job.startedAt)}:null;}
async function saveSearchImpl(values){if(['job','selection','inventorySelection','dailyPendingDay','dailyStartedDay'].some(k=>Object.hasOwn(values,k)))values.statusRevision=crypto.randomUUID();if(values.job)values.jobProgress=summary(values.job,{jobId:values.job.id,pages:values.job.pages,status:values.job.status,skipUnchanged:true});if(values.job?.kind==='auto')values.dailyProgress=dailyProgressOf(values.job);if(['last','manualFeeds','inventoryFeeds'].some(k=>Object.hasOwn(values,k)))values.resultRevision=crypto.randomUUID();if(values.job?.kind==='auto')values.dailyJob=values.job;if(values.job?.kind==='batch-buyers')values.batchBuyerJob=values.job;if(values.job?.kind==='batch-inventory')values.batchInventoryJob=values.job;if(values.job&&values.job.status!=='running'){const job=values.job,members=job.selection?.length?job.selection:job.buyerId?[{id:job.buyerId,demands:job.demands}]:[];if(members.length){const saved=await BuyerStorage.get('memberReports'),reports=saved.memberReports||{};for(const member of members){if(job.detailRetryFinishedAt&&Date.parse(reports[member.id]?.at)>Date.parse(job.startedAt))continue;reports[member.id]={id:job.id,at:job.startedAt,kind:job.kind,demands:member.demands,report:buildDailyReport({...job,selection:members},String(member.id))};}values.memberReports=reports;}}return BuyerStorage.set(values);}
async function resumeAlarm(){await chrome.alarms.create('buyer-continue',{delayInMinutes:0.5});}
async function saveSearch(values){return timedSearch('save','local',()=>saveSearchImpl(values));}
async function startSearch(ds,kind='manual',selection=[],buyerId='',dailyDay=''){if(starting)throw Error('正在建立搜尋');starting=true;try{const prior=(await BuyerStorage.get('job')).job;if(prior?.status==='running')throw Error('已有逐頁搜尋進行中，請等待完成或先取消');const demands=cleanDemands(ds);if(demands.some(d=>!d.areaCities?.length&&!d.areaDists?.length))throw Error('請先指定搜尋縣市或行政區，避免意外搜尋全台');const todo=tasksFor(demands);if(!todo.length)throw Error('請選擇有效的縣市與行政區');const now=new Date().toISOString(),job={id:crypto.randomUUID(),kind,selection,buyerId,dailyDay,demands,status:'running',startedAt:now,lastProgressAt:now,active:[],failures:[],scopeStates:Object.fromEntries(todo.map(t=>[t.key,'pending'])),todo,totalScopes:todo.length,doneScopes:0,pages:0,scanned:0,listings:{},sources:{},seen:{}};if(prior?.kind==='auto')await saveSearch({dailyJob:prior});await BuyerStorage.remove('cancelledJob');await saveSearch({job});await resumeAlarm();return {jobId:job.id};}finally{starting=false;}}
function summary(job,cursor={}){return job?{id:job.id,kind:job.kind,buyerId:job.buyerId,status:job.status,startedAt:job.startedAt,lastProgressAt:job.lastProgressAt,active:job.active||[],failures:job.failures||[],pages:job.pages,scanned:job.scanned,count:job.count??Object.keys(job.listings).length,doneScopes:job.doneScopes,totalScopes:job.totalScopes,error:job.error,sources:Object.values(job.sources),buyerIds:(job.selection||[]).map(s=>String(s.id)),feed:job.status==='running'?(job.pages>0&&(cursor.jobId!==job.id||cursor.pages!==job.pages)?{schema:1,includeExcluded:true,incremental:true,generatedAt:job.startedAt,sources:Object.values(job.sources).map(s=>({...s,status:s.pages?'partial':'error',coverage:'搜尋進行中，尚未完整'})),listings:Object.values(job.listings)}:undefined):cursor.skipUnchanged&&cursor.jobId===job.id&&cursor.pages===job.pages&&cursor.status===job.status?undefined:job.feed}:null;}
async function runChunk(){if(working)return;working=true;try{let {job,history={},ownedTab}=await BuyerStorage.get(['job','history','ownedTab']);if(ownedTab){const orphan=await chrome.tabs.get(ownedTab).catch(()=>null);if(orphan?.url&&['buy.yungching.com.tw','www.sinyi.com.tw','sale.591.com.tw','business.591.com.tw','www.rakuya.com.tw','www.leju.com.tw'].includes(new URL(orphan.url).hostname))await chrome.tabs.remove(ownedTab).catch(()=>{});await BuyerStorage.remove('ownedTab');}if(!job||job.status!=='running')return;if(job.detailRetry){await runDailyDetailRetry(job);return;}job.todo=job.todo.filter(t=>['yungching','sinyi','591'].includes(t.source));for(const source of ['rakuya','leju'])delete job.sources[source];job.doneScopes=Object.values(job.sources).reduce((n,s)=>n+(s.completedScopes||0)+(s.failedPages||0),0);job.totalScopes=job.doneScopes+job.todo.length;if((await BuyerStorage.get('cancelledJob')).cancelledJob===job.id){job.finishedAt=new Date().toISOString();job.status='cancelled';await saveSearch({job});return;}await resumeAlarm();const owned=await BuyerStorage.get(['ownedTab_yungching','ownedTab_sinyi','ownedTab_591']);for(const id of Object.values(owned)){if(Number.isInteger(id))await chrome.tabs.remove(id).catch(()=>{});}await BuyerStorage.remove(['ownedTab_yungching','ownedTab_sinyi','ownedTab_591']);searchTabs=[];const until=Date.now()+60000;
 while(job.todo.length&&Date.now()<until){const batch=[],used=new Set();for(const t of job.todo){if(used.size<searchConcurrency()&&!used.has(t.source)){used.add(t.source);batch.push(t);}}job.active=batch.map(t=>({key:t.key,source:t.source,district:t.district,keyword:t.keyword,startedAt:new Date().toISOString()}));await saveSearch({job});const pending=new Map(batch.map(task=>[task.key,readWithDeadline({...task,roundId:job.id}).then(data=>({task,data}),error=>({task,error}))]));while(pending.size){const {task,data,error}=await Promise.race(pending.values());pending.delete(task.key);job.active=job.active.filter(t=>t.key!==task.key);job.lastProgressAt=new Date().toISOString();const guard=(await BuyerStorage.get('job')).job;if(guard?.id!==job.id||guard.status!=='running'){await Promise.allSettled(pending.values());return;}job.todo=job.todo.filter(t=>t.key!==task.key);const s=job.sources[task.source]||{id:task.source,status:'running',pages:0,count:0,completedScopes:0,failedPages:0,coverage:'依必要條件與各路段搜尋，尚未完成'};try{if(error)throw error;const ids=data.rows.map(r=>r.id).sort();if(task.visited.includes(task.url)||(ids.length&&ids.join('|')===task.lastIds.join('|')))throw Error('翻頁回傳重複內容，停止此區避免假完成');s.pages++;job.pages++;job.scanned+=data.rows.length;const now=new Date().toISOString();for(const row of filterTaskRows(data.rows,task)){const old=history[row.id];job.seen[row.id]={firstSeenAt:old?.firstSeenAt||job.startedAt,price:row.price,seenAt:now};{job.listings[row.id]={...BuyerMatchEngine.mergeListingFields(job.listings[row.id],row,now),firstSeenAt:old?.firstSeenAt||job.startedAt,seenAt:now,discovery:old?'seen':'new',previousPrice:old?.price!==row.price?old?.price:undefined};}}
 if(data.next){const next=new URL(data.next);if(next.origin!==new URL(task.url).origin||!/^https:/.test(next.protocol))throw Error('下一頁網址不屬於原站');job.todo.push({...task,url:next.href,first:false,visited:[...task.visited,task.url],lastIds:ids});}else if(data.complete){job.doneScopes++;s.completedScopes++;if(job.scopeStates)job.scopeStates[task.key]='completed';}else throw Error('找不到可確認的下一頁或末頁');
 }catch(e){if(job.scopeStates)job.scopeStates[task.key]='failed';s.failedPages++;s.reason=e.message;(job.failures||(job.failures=[])).push({source:task.source,district:task.district,keyword:task.keyword,reason:e.message,task:{...task}});job.doneScopes++;}s.count=Object.values(job.listings).filter(p=>p.source===task.source).length;const pendingSource=job.todo.some(t=>t.source===task.source);s.status=pendingSource?'running':s.failedPages?(s.pages?'partial':'error'):'ok';s.coverage=pendingSource?'依必要條件與各路段搜尋，尚未完成':s.failedPages?'部分搜尋條件未完成':'已讀至此來源各搜尋條件的原站末頁';job.sources[task.source]=s;const latest=(await BuyerStorage.get('job')).job;if(latest?.id!==job.id||latest.status==='cancelled'||(await BuyerStorage.get('cancelledJob')).cancelledJob===job.id)return;if(Date.now()<until&&pending.size<searchConcurrency()){const idle=t=>!job.active.some(a=>a.source===t.source);const nextTask=job.todo.find(t=>idle(t)&&t.source!==task.source)||job.todo.find(idle);if(nextTask){job.active.push({key:nextTask.key,source:nextTask.source,district:nextTask.district,keyword:nextTask.keyword,startedAt:new Date().toISOString()});pending.set(nextTask.key,delay(1500).then(()=>readWithDeadline({...nextTask,roundId:job.id})).then(data=>({task:nextTask,data}),error=>({task:nextTask,error})));}}await saveSearch({job});}}
 if(job.todo.length){await resumeAlarm();return;}const now=new Date().toISOString();for(const s of Object.values(job.sources)){s.status=s.failedPages?(s.pages?'partial':'error'):'ok';s.checkedAt=now;s.detailFailures=Object.values(job.listings).filter(p=>p.source===s.id&&p.detailStatus==='failed'&&!BuyerMatchEngine.isParkingOnly(p)).length;if(s.detailFailures)s.status='partial';s.coverage=s.failedPages?'部分搜尋條件未完成':`已讀至各搜尋條件的原站末頁（${s.pages} 頁）`;}
 for(const s of Object.values(job.sources))if(s.detailFailures)s.coverage+='；詳細欄位補讀失敗 '+s.detailFailures+' 筆';
 job.finishedAt=now;job.status=Object.values(job.sources).some(s=>s.failedPages||s.detailFailures)?'partial':'completed';job.feed={schema:1,searchScopes:Object.fromEntries((job.selection?.length?job.selection:job.buyerId?[{id:job.buyerId,demands:job.demands}]:[]).map(member=>[String(member.id),BuyerMatchEngine.searchScope(member.demands)])),scanId:job.scanId||job.id,includeExcluded:true,generatedAt:now,coverage:'已逐頁讀取；完成範圍依各來源狀態，受原站可見結果上限限制',sources:Object.values(job.sources),listings:Object.values(job.listings)};for(const [id,v]of Object.entries(job.seen))history[id]=v;job.seen={};job.todo=[];job.count=Object.keys(job.listings).length;job.listings={};const patch={job,history};if(job.feed.sources.some(s=>s.status==='ok'||s.status==='partial')){if(job.kind==='batch-buyers'||job.kind==='batch-inventory'){const field=job.kind==='batch-buyers'?'manualFeeds':'inventoryFeeds',saved=await BuyerStorage.get(field),feeds=saved[field]||{};for(const member of job.selection||[])feeds[String(member.id)]=job.feed;patch[field]=feeds;}else if(job.kind==='inventory'){const {inventoryFeeds={}}=await BuyerStorage.get('inventoryFeeds');inventoryFeeds[job.buyerId]=job.feed;patch.inventoryFeeds=inventoryFeeds;}else if(job.kind==='auto'){job.feed.inventoryIds=(job.selection||[]).filter(x=>String(x.id).startsWith('inventory:')).map(x=>x.id);patch.last=job.feed;patch.lastError=job.status==='partial'?'部分來源未完成，請查看來源狀態':null;}else {patch.lastManual=job.feed;const {manualFeeds={}}=await BuyerStorage.get('manualFeeds');if(job.buyerId)manualFeeds[job.buyerId]=job.feed;patch.manualFeeds=manualFeeds;}}else if(job.kind==='auto')patch.lastError='各來源均未取得資料，保留上次結果';await saveSearch(patch);await chrome.alarms.clear('buyer-continue');if((await BuyerStorage.get('reloadPending')).reloadPending){await BuyerStorage.remove('reloadPending');const {reloadTab}=await BuyerStorage.get('reloadTab');if(reloadTab)await saveSearch({reloadTab:{...reloadTab,at:Date.now()}});chrome.runtime.reload();}
 }catch(e){const {job}=await BuyerStorage.get('job');if(job){job.finishedAt=new Date().toISOString();job.status='partial';job.error='搜尋中斷：'+e.message;await saveSearch({job,...(job.kind==='auto'?{lastError:job.error}:{})});}}finally{await closeSearchTabs();await flushSearchMetrics(true);working=false;}}
// Resume only failed detail IDs from the selected daily report, without enumerating search pages.
async function startDailyDetailRetry(payload={}){
 if(starting)throw Error('正在建立搜尋');starting=true;
 try{
  const saved=await BuyerStorage.get(['job','dailyJob']);if(saved.job?.status==='running')throw Error('已有搜尋進行中，請等待完成');
  const old=saved.dailyJob||(saved.job?.kind==='auto'?saved.job:null);
  if(!old||old.id!==payload.jobId||old.status==='running')throw Error('報告已更新，請重新開啟後重試');
  const issues=buildDailyReport(old).detailIssues||[],ids=new Set(issues.map(p=>p.id));
  const listings={...(old.listings||{}),...Object.fromEntries((old.feed?.listings||[]).map(p=>[p.id,p]))};
  const pending=Object.values(listings).filter(p=>ids.has(p.id)&&['591','sinyi','yungching'].includes(p.source)).map(p=>p.id);
  if(!pending.length)throw Error('目前沒有補讀失敗物件');
  const now=new Date().toISOString(),job={...old,feed:old.feed||{schema:1,scanId:old.scanId||old.id,includeExcluded:true,generatedAt:old.finishedAt||old.startedAt,sources:Object.values(old.sources||{}),listings:Object.values(listings)},status:'running',listings,active:[],lastProgressAt:now,detailRetry:{pending,total:pending.length,done:0,startedAt:now}};
  await BuyerStorage.remove('cancelledJob');await saveSearch({job});await resumeAlarm();return {jobId:job.id,total:pending.length};
 }finally{starting=false;}
}
async function runDailyDetailRetry(job){
 const until=Date.now()+60000;
 while(job.detailRetry.pending.length){
  const latest=(await BuyerStorage.get('job')).job;if(latest?.id!==job.id||latest.status!=='running')return;
  const first=job.listings[job.detailRetry.pending[0]],ids=job.detailRetry.pending.filter(id=>job.listings[id]?.source===first?.source).slice(0,3),rows=ids.map(id=>job.listings[id]);
  job.active=[{source:first.source,detailRetry:true}];job.lastProgressAt=new Date().toISOString();await saveSearch({job});
  let checks;try{checks=(await buyerVerify({rows})).checks||[];}catch(error){checks=rows.map(p=>({id:p.id,availability:'unknown',detailStatus:'failed',detailAttemptedAt:new Date().toISOString(),detailError:String(error.message||error)}));}
  const current=(await BuyerStorage.get('job')).job;if(current?.id!==job.id||current.status!=='running')return;
  for(const row of rows){const fresh={...row};for(const key of ['detailError','detailCheckedAt','detailRateLimited','detailRetryAt','availabilityReason'])delete fresh[key];const check=checks.find(p=>p.id===row.id)||{availability:'unknown',detailStatus:'failed',detailError:'核對未回傳結果',detailAttemptedAt:new Date().toISOString()};job.listings[row.id]={...fresh,...check,detailAttempts:(row.detailAttempts||0)+1,seenAt:new Date().toISOString()};}
  const processed=new Set(ids);job.detailRetry.pending=job.detailRetry.pending.filter(id=>!processed.has(id));job.detailRetry.done+=ids.length;job.lastProgressAt=new Date().toISOString();job.active=[];
  job.feed={...job.feed,incremental:true,listings:Object.values(job.listings)};await saveSearch({job});await flushSearchMetrics(true);
  if(Date.now()>=until&&job.detailRetry.pending.length){await resumeAlarm();return;}
 }
 const retry=job.detailRetry;job.detailRetryStartedAt=retry.startedAt;job.detailRetryFinishedAt=new Date().toISOString();job.detailRetryTotal=retry.total;delete job.detailRetry;
 const scopes=buildDailyReport({...job,status:'partial'}).scopes;
 for(const source of Object.values(job.sources)){source.detailFailures=Object.values(job.listings).filter(p=>p.source===source.id&&p.detailStatus==='failed'&&!BuyerMatchEngine.isParkingOnly(p)).length;source.status=source.failedPages||scopes.some(t=>t.source===source.id)?(source.status==='error'?'error':'partial'):source.detailFailures?'partial':'ok';source.coverage=String(source.coverage||'').replace(/；詳細欄位補讀失敗 \d+ 筆/g,'')+(source.detailFailures?'；詳細欄位補讀失敗 '+source.detailFailures+' 筆':'');}
 job.status=!job.error&&!scopes.length&&!Object.values(job.listings).some(p=>p.detailStatus==='failed'&&!BuyerMatchEngine.isParkingOnly(p))?'completed':'partial';
 job.feed={...job.feed,sources:Object.values(job.sources),listings:Object.values(job.listings)};job.count=job.feed.listings.length;job.listings={};
 await saveSearch({job,last:job.feed,lastError:job.status==='partial'?'部分資料仍未核實，請查看報告':null});await chrome.alarms.clear('buyer-continue');
}
async function retryFailed(payload,daily=false,batch=null){
 if(starting)throw Error('正在建立搜尋');starting=true;
 try{const saved=await BuyerStorage.get(['job','dailyJob','batchBuyerJob','batchInventoryJob','selection','inventorySelection']);if(saved.job?.status==='running')throw Error('已有搜尋進行中，請等待完成');const old=batch?saved[batch==='buyers'?'batchBuyerJob':'batchInventoryJob']:daily?(saved.dailyJob||(saved.job?.kind==='auto'?saved.job:null)):saved.job;if(!old||old.status==='running')throw Error('請先等待搜尋結束或停止搜尋');const selected=old.selection?.find(c=>String(c.id)===String(payload?.buyerId));if(!daily&&!batch&&((String(payload?.buyerId||'')!==String(old.buyerId||'')&&!selected)||JSON.stringify(cleanDemands(payload.demands))!==JSON.stringify(cleanDemands(selected?.demands||old.demands))))throw Error('買方或需求已變更，請重新搜尋');
 if(batch&&JSON.stringify(old.selection)!==JSON.stringify(saved[batch==='buyers'?'selection':'inventorySelection']||[]))throw Error('設定已變更，請重新執行一鍵搜尋');
 if(daily&&JSON.stringify(old.selection)!==JSON.stringify([...(saved.selection||[]),...(saved.inventorySelection||[])]))throw Error('自動搜尋設定已變更，請執行今日自動搜尋');
 const pending=[...(old.failures||[]).map(f=>f.task).filter(Boolean),...(old.todo||[])],todo=[...new Map(pending.map(t=>[t.key,{...t,visited:[],lastIds:[]}])).values()];if(!todo.length)throw Error('沒有可重試的未完成搜尋；舊版助手請重新搜尋一次');
 const sources=structuredClone(old.sources||{});for(const source of new Set(todo.map(t=>t.source))){const row=sources[source];if(row){row.failedPages=0;row.reason='';row.status='running';}}
 const now=new Date().toISOString(),job={...old,scanId:old.scanId||old.id,id:crypto.randomUUID(),initialStartedAt:old.initialStartedAt||old.startedAt,startedAt:now,finishedAt:null,lastProgressAt:now,status:'running',error:undefined,active:[],failures:[],todo,sources,seen:{},listings:{...(old.listings||{}),...Object.fromEntries((old.feed?.listings||[]).map(p=>[p.id,p]))}};if(job.scopeStates)for(const t of todo)job.scopeStates[t.key]='pending';job.doneScopes=Object.values(sources).reduce((n,s)=>n+(s.completedScopes||0),0);job.totalScopes=job.doneScopes+todo.length;delete job.feed;delete job.count;await BuyerStorage.remove('cancelledJob');await saveSearch({job});await resumeAlarm();return {jobId:job.id};
 }finally{starting=false;}
}
function localDay(){const d=new Date();return [d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-');}
async function startPendingDaily(){const saved=await BuyerStorage.get(['dailyPendingDay','dailyStartedDay','job','selection','inventorySelection']);const day=saved.dailyPendingDay;if(!day)return false;if(saved.dailyStartedDay===day||saved.job?.dailyDay===day){await BuyerStorage.remove('dailyPendingDay');return false;}if(saved.job?.status==='running'||starting)return false;const selection=[...(saved.selection||[]),...(saved.inventorySelection||[])];if(!selection.length){await BuyerStorage.remove('dailyPendingDay');return false;}try{await startSearch(selection.flatMap(s=>s.demands),'auto',selection,'',day);await saveSearch({dailyStartedDay:day});await BuyerStorage.remove('dailyPendingDay');return true;}catch(e){await saveSearch({lastError:'定時配對等待補跑：'+e.message});await resumeAlarm();return false;}}
async function runContinuous(){if(continuing)return;continuing=true;try{do{await runChunk();const {job}=await BuyerStorage.get('job');if(!job||job.status!=='running'||(!job.todo?.length&&!job.detailRetry)){if(await startPendingDaily())continue;break;}}while(true);}finally{continuing=false;}}
async function schedule(){if(!(await chrome.alarms.get('buyer-daily'))){const now=new Date(),at=new Date();at.setHours(8,25,0,0);if(at<=now)at.setDate(at.getDate()+1);await chrome.alarms.create('buyer-daily',{when:at.getTime(),periodInMinutes:1440});}const saved=await BuyerStorage.get(['job','dailyPendingDay']);if(saved.job?.status==='running'||saved.dailyPendingDay)await resumeAlarm();}
chrome.runtime.onInstalled.addListener(async()=>{await schedule();const {reloadTab}=await BuyerStorage.get('reloadTab');if(reloadTab){await BuyerStorage.remove('reloadTab');const tab=await chrome.tabs.get(reloadTab.id).catch(()=>null);if(tab?.url?.startsWith(CRM)&&Date.now()-reloadTab.at<300000)await chrome.tabs.reload(tab.id).catch(()=>{});}});chrome.runtime.onStartup.addListener(schedule);
chrome.alarms.onAlarm.addListener(async a=>{if(a.name==='buyer-continue')return runContinuous();if(a.name!=='buyer-daily')return;await saveSearch({dailyPendingDay:localDay()});await resumeAlarm();await startPendingDaily();await runContinuous();});
// Runtime responses are capped by Chrome; transfer large JSON in bounded pieces.
const responseTransfers=new Map();
const RESPONSE_CHUNK=256*1024,RESPONSE_TTL=120000;
function transferOwner(sender){return String(sender.tab?.id)+':'+String(sender.frameId||0)+':'+String(sender.documentId||sender.url);}
function pruneTransfers(){for(const [id,t] of responseTransfers)if(t.expires<Date.now())responseTransfers.delete(id);}
function prepareResponse(value,sender){
 const json=timedSearchSync('encode',()=>JSON.stringify(value));if(!json||json.length<=RESPONSE_CHUNK)return value;
 pruneTransfers();let used=0;for(const t of responseTransfers.values())used+=t.json.length;
 if(used+json.length>256*1024*1024)throw Error('結果傳送忙碌中，請稍後重新讀取；原資料已保留');
 const token=crypto.randomUUID();responseTransfers.set(token,{json,owner:transferOwner(sender),expires:Date.now()+RESPONSE_TTL});
 return {__crmTransfer:1,token,length:json.length,count:Math.ceil(json.length/RESPONSE_CHUNK)};
}
function readTransfer(msg,sender){
 pruneTransfers();const t=responseTransfers.get(msg.token);
 if(!t||t.owner!==transferOwner(sender))throw Error('結果傳送已中斷或逾時，請重新讀取結果；原資料已保留');
 if(msg.type==='transferRelease'){responseTransfers.delete(msg.token);return {released:true};}
 if(!Number.isInteger(msg.index)||msg.index<0||msg.index>=Math.ceil(t.json.length/RESPONSE_CHUNK))throw Error('結果分段索引不正確');
 t.expires=Date.now()+RESPONSE_TTL;return {index:msg.index,text:t.json.slice(msg.index*RESPONSE_CHUNK,(msg.index+1)*RESPONSE_CHUNK)};
}
function safeReply(reply,value){try{reply(value);}catch(error){console.warn('CRM response delivery failed:',String(error.message||error));}}
chrome.runtime.onMessage.addListener((msg,sender,reply)=>{if(msg.type==='detail591Fetch'){detail591Request(msg,sender).then(value=>safeReply(reply,value),error=>safeReply(reply,{error:error.message}));return true;}if(!sender.url?.startsWith(CRM))return;const go=async()=>{if(msg.type==='activity'){lastCRMActivity=Date.now();return {ok:true};}if(['transferRead','transferRelease'].includes(msg.type))return readTransfer(msg,sender);if(msg.type==='batchSearch')return startBatch(msg.payload?.scope);if(msg.type==='batchStatus')return batchStatus(msg.payload?.scope,msg.payload?.revision);if(msg.type==='batchRetry'){if(!['buyers','inventory'].includes(msg.payload?.scope))throw Error('搜尋類別不正確');return retryFailed({},false,msg.payload.scope);}if(msg.type==='dailyStatus')return dailyStatus(msg.payload);if(msg.type==='dailyDetailsRetry')return startDailyDetailRetry(msg.payload);if(msg.type==='dailyRetry')return retryFailed({},true);if(msg.type==='dailyRun'){const saved=await BuyerStorage.get(['selection','inventorySelection']);const selected=[...(saved.selection||[]),...(saved.inventorySelection||[])];return startSearch(selected.flatMap(s=>s.demands),'auto',selected,'',localDay());}if(msg.type==='hello')return {version:3,extensionVersion:chrome.runtime.getManifest().version};if(msg.type==='reload'){if(sender.tab?.id)await saveSearch({reloadTab:{id:sender.tab.id,at:Date.now()}});const {job}=await BuyerStorage.get('job');if(job?.status==='running'){await saveSearch({reloadPending:true});return {deferred:true};}setTimeout(()=>chrome.runtime.reload(),500);return {reloading:true};}if(msg.type==='sync'){if(!Array.isArray(msg.payload)||msg.payload.length>100||msg.payload.some(x=>!Array.isArray(x.demands)||x.demands.length>10))throw Error('最多 100 位買方，每位 10 組需求；原設定保持不變');const selection=msg.payload.map(x=>({id:String(x.id),demands:cleanDemands(x.demands)}));const syncedAt=new Date().toISOString();await saveSearch({selection,syncedAt});return {saved:selection.length,syncedAt};}if(msg.type==='inventorySync'){if(!Array.isArray(msg.payload)||msg.payload.length>50)throw Error('最多追蹤50筆庫存');const inventorySelection=msg.payload.map(x=>{if(!String(x.id).startsWith('inventory:'))throw Error('庫存識別不符');return {id:String(x.id),demands:cleanDemands(x.demands)};});await saveSearch({inventorySelection});return {saved:inventorySelection.length};}if(msg.type==='buyerVerify')return buyerVerify(msg.payload);if(msg.type==='inventoryVerify')return inventoryVerify(msg.payload);if(msg.type==='inventorySearch')return startSearch(msg.payload?.demands,'inventory',[],String(msg.payload?.id||''));if(msg.type==='last')return lastResults(msg.payload);if(msg.type==='progress'){if(msg.payload?.skipUnchanged){const {jobProgress}=await BuyerStorage.get('jobProgress');if(jobProgress&&msg.payload.jobId===jobProgress.id&&msg.payload.pages===jobProgress.pages&&msg.payload.status===jobProgress.status)return {job:jobProgress};}return {job:summary((await BuyerStorage.get('job')).job,msg.payload)};}if(msg.type==='cancel'){const {job}=await BuyerStorage.get('job');if(msg.payload?.jobId&&job?.id!==msg.payload.jobId)throw Error('搜尋任務已變更，請更新狀態後再試');if(job?.status==='running'){await saveSearch({cancelledJob:job.id});job.status='cancelled';if(job.detailRetry){job.detailRetryStoppedAt=new Date().toISOString();delete job.detailRetry;job.active=[];job.feed={...job.feed,incremental:true,listings:Object.values(job.listings)};}else{job.finishedAt=new Date().toISOString();job.feed={schema:1,includeExcluded:true,generatedAt:new Date().toISOString(),sources:Object.values(job.sources).map(s=>({...s,status:s.pages?'partial':'error',coverage:'使用者停止，未完整搜尋'})),listings:Object.values(job.listings)};}await saveSearch({job});await chrome.alarms.clear('buyer-continue');const owned=await BuyerStorage.get(['ownedTab','ownedTab_yungching','ownedTab_sinyi','ownedTab_591']);for(const id of Object.values(owned))if(Number.isInteger(id))await chrome.tabs.remove(id).catch(()=>{});}return {cancelled:true,job:summary(job)};}if(msg.type==='retry')return retryFailed(msg.payload);if(msg.type==='search')return startSearch(msg.payload?.demands,'manual',[],String(msg.payload?.buyerId||''));throw Error('不支援的操作');};go().then(result=>{try{safeReply(reply,['transferRead','transferRelease'].includes(msg.type)?result:prepareResponse(result,sender));}catch(e){safeReply(reply,{error:e.message});}if(['search','retry','inventorySearch','dailyRetry','dailyRun','batchSearch','batchRetry','dailyDetailsRetry'].includes(msg.type))runContinuous().catch(e=>console.error('CRM search failed:',e.message));},e=>safeReply(reply,{error:e.message}));return true;});

// Inventory idle polling must not transfer every buyer's saved search results.
async function lastResults(payload={}){
 if(!['inventory','buyers'].includes(payload?.scope))return BuyerStorage.get(['last','lastError','syncedAt','manualFeeds','inventoryFeeds']);
 let {resultRevision}=await BuyerStorage.get('resultRevision');
 if(!resultRevision){resultRevision=crypto.randomUUID();await BuyerStorage.set({resultRevision});}
 if(resultRevision&&payload.revision===resultRevision)return {revision:resultRevision,unchanged:true};
 if(payload.scope==='buyers'){const data=await BuyerStorage.get(['last','manualFeeds']);return {revision:resultRevision,last:data.last,manualFeeds:data.manualFeeds||{}};}
 const data=await BuyerStorage.get(['last','inventoryFeeds']);
 return {revision:resultRevision,inventoryFeeds:data.inventoryFeeds||{},...(data.last?.inventoryIds?.length?{last:data.last}:{})};
}
async function dailyStatus(payload={}){
 if(payload?.progressOnly){let {dailyProgress}=await BuyerStorage.get('dailyProgress');if(!dailyProgress){const saved=await BuyerStorage.get(['dailyJob','job']);dailyProgress=dailyProgressOf(saved.dailyJob||(saved.job?.kind==='auto'?saved.job:null));}return {progress:dailyProgress};}

 const {statusRevision}=await BuyerStorage.get('statusRevision'),revision=statusRevision?[statusRevision,localDay(),String(payload.memberId||'')].join('|'):undefined;
 if(revision&&payload.revision===revision)return {revision,unchanged:true,scoped:!!payload.memberId,memberId:String(payload.memberId||'')};
 const saved=await BuyerStorage.get(['dailyJob','job','memberReports','batchBuyerJob','batchInventoryJob','dailyPendingDay','dailyStartedDay','lastAt','selection','inventorySelection']);
 const job=saved.dailyJob||(saved.job?.kind==='auto'?saved.job:null),today=localDay();
 const selected=[...(saved.selection||[]),...(saved.inventorySelection||[])];
 const day=job?.dailyDay||(job?.startedAt?localDate(job.startedAt):'');
 const memberId=payload?.memberId?String(payload.memberId):'',member=memberId?job?.selection?.find(s=>String(s.id)===memberId):null;
 const report=job&&(!memberId||member)?buildDailyReport(job,memberId):null;
 const current=day===today&&(!memberId||!!member);
 const currentSelection=memberId?selected.filter(s=>String(s.id)===memberId):selected,priorSelection=memberId?(member?[member]:[]):job?.selection;
 const candidates=memberId?[saved.memberReports?.[memberId],...[saved.dailyJob,saved.batchBuyerJob,saved.batchInventoryJob,saved.job].filter(Boolean).map(j=>{const m=j.selection?.find(x=>String(x.id)===memberId)||(String(j.buyerId||'')===memberId?{id:memberId,demands:j.demands}:null);return m?{id:j.id,at:j.startedAt,kind:j.kind,demands:m.demands,report:buildDailyReport({...j,selection:j.selection?.length?j.selection:[m]},memberId)}:null;})].filter(Boolean):[];
 candidates.sort((a,b)=>Date.parse(b.at||b.report.startedAt)-Date.parse(a.at||a.report.startedAt)||Date.parse(b.report.lastProgressAt||b.report.startedAt)-Date.parse(a.report.lastProgressAt||a.report.startedAt)||Number(b.report.reportVersion||0)-Number(a.report.reportVersion||0)||Number(Array.isArray(b.report.detailIssues))-Number(Array.isArray(a.report.detailIssues)));
 const latest=candidates[0];if(latest)latest.settingsChanged=currentSelection.length>0&&JSON.stringify(latest.demands)!==JSON.stringify(currentSelection[0].demands);
 return {revision,latest,scoped:!!memberId,memberId,notIncluded:!!memberId&&day===today&&!member,today,day,current,report,missing:!current&&(saved.dailyStartedDay===today||saved.lastAt&&localDate(saved.lastAt)===today),queued:saved.dailyPendingDay===today,busy:saved.job?.status==='running',expected:{buyers:selected.filter(s=>!String(s.id).startsWith('inventory:')).length,inventory:selected.filter(s=>String(s.id).startsWith('inventory:')).length},settingsChanged:current&&JSON.stringify(priorSelection)!==JSON.stringify(currentSelection)};
}
function localDate(value){const d=new Date(value);return [d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-');}
function buildDailyReport(job,memberId=''){
 const all=tasksFor(job.demands),waiting=new Set((job.todo||[]).map(t=>t.key)),failed=new Map((job.failures||[]).filter(f=>f.task).map(f=>[f.task.key,f]));
 const state=t=>job.scopeStates?.[t.key]||(failed.has(t.key)?'failed':waiting.has(t.key)?'pending':job.sources?.[t.source]?.status==='ok'&&job.sources[t.source].completedScopes===all.filter(a=>a.source===t.source).length?'completed':'unknown');
 const relevant=memberId?new Set(tasksFor(job.selection.find(s=>String(s.id)===memberId).demands).map(t=>t.key)):null;
 const scopes=all.filter(t=>!relevant||relevant.has(t.key)).map(t=>({key:t.key,source:t.source,district:t.district,keyword:t.keyword,category:t.source==='591'?new URL(t.url).hostname==='business.591.com.tw'?({5:'店面',6:'辦公',7:'廠房',12:'住辦'})[new URL(t.url).searchParams.get('kind')]||'商用':'中古屋':'',status:state(t),reason:failed.get(t.key)?.reason||''}));
 const allDetailRows=Object.values(job.feed?Object.fromEntries((job.feed.listings||[]).map(p=>[p.id,p])):job.listings||{}).filter(p=>p.detailStatus==='failed');
 const detailRows=allDetailRows.filter(p=>!BuyerMatchEngine.isParkingOnly(p));
 const detailFor=ds=>detailRows.filter(p=>ds.some(d=>BuyerMatchEngine.evaluate(d,p).status!=='excluded'));
 const relevantDetails=memberId?detailFor(job.selection.find(s=>String(s.id)===memberId).demands):detailRows;
 const members=(job.selection||[]).filter(s=>!memberId||String(s.id)===memberId).map(s=>{const ts=tasksFor(s.demands);return {id:s.id,completed:ts.length>0&&ts.every(t=>state(t)==='completed')&&!detailFor(s.demands).length};});
 const group=inventory=>{const list=members.filter(m=>String(m.id).startsWith('inventory:')===inventory);return {total:list.length,completed:list.filter(m=>m.completed).length};};
 const sources=['yungching','sinyi','591'].map(id=>{const list=scopes.filter(t=>t.source===id);return {id,total:list.length,completed:list.filter(t=>t.status==='completed').length,failed:list.filter(t=>t.status==='failed').length,unknown:list.filter(t=>t.status==='unknown').length,pending:list.filter(t=>t.status==='pending').length,count:memberId?undefined:job.sources?.[id]?.count||0};});
 const complete=!relevantDetails.length&&scopes.length>0&&scopes.every(t=>t.status==='completed')&&(memberId||!job.error&&(job.status==='completed'||job.status==='partial'&&allDetailRows.length>0&&allDetailRows.every(p=>BuyerMatchEngine.isParkingOnly(p))));
 return {reportVersion:2,jobId:job.id,detailRetry:job.detailRetry?{done:job.detailRetry.done,total:job.detailRetry.total,startedAt:job.detailRetry.startedAt}:null,detailRetryFinishedAt:job.detailRetryFinishedAt,detailRetryTotal:job.detailRetryTotal,canRetryDetails:job.status!=='running'&&relevantDetails.length>0,status:complete?'completed':job.status==='running'?'running':'partial',startedAt:job.initialStartedAt||job.startedAt,finishedAt:job.finishedAt||job.feed?.generatedAt,lastProgressAt:job.lastProgressAt,buyers:group(false),inventory:group(true),members,sources,scopes:scopes.filter(t=>t.status!=='completed'),detailIssues:relevantDetails.map(p=>({id:p.id,title:p.title||p.id,source:p.source,url:p.url||'',reason:p.detailError||'原站資料不足，尚未確認連結有效',attemptedAt:p.detailAttemptedAt||null,attempts:p.detailAttempts??null})),canRetry:scopes.some(t=>t.status==='failed'||t.status==='pending'),error:complete?'':[job.error,relevantDetails.length?'詳細欄位補讀失敗 '+relevantDetails.length+' 筆，請查看下方「待核對物件」'+(relevantDetails.some(p=>p.detailRateLimited)?'。原站限流期間已停止補讀，請等待冷卻後再重試；不要連續執行整批搜尋。':'。可從早上報告按「重試失敗物件」只補讀這些刊登。'):''].filter(Boolean).join('；'),legacy:!job.scopeStates};
}

async function startBatch(scope){if(!['buyers','inventory'].includes(scope))throw Error('搜尋類別不正確');const field=scope==='buyers'?'selection':'inventorySelection',saved=await BuyerStorage.get(field),selected=saved[field]||[];if(!selected.length)throw Error(scope==='buyers'?'尚無開啟自動配對的買方':'尚無開啟案件追蹤的庫存');return startSearch(selected.flatMap(s=>s.demands),'batch-'+scope,selected);}
async function batchStatus(scope,cursor){if(!['buyers','inventory'].includes(scope))throw Error('搜尋類別不正確');const {statusRevision}=await BuyerStorage.get('statusRevision'),revision=statusRevision?[statusRevision,scope].join('|'):undefined;if(revision&&cursor===revision)return {scope,revision,unchanged:true};const key=scope==='buyers'?'batchBuyerJob':'batchInventoryJob',saved=await BuyerStorage.get([key,'job']),job=saved[key];return {revision,id:job?.id,scope,busy:saved.job?.status==='running',runningScope:saved.job?.status==='running'?saved.job.kind:null,report:job?buildDailyReport(job):null};}

const unmeasuredDailyReport=buildDailyReport;
buildDailyReport=function(job,memberId=''){return timedSearchSync('report',()=>unmeasuredDailyReport(job,memberId));};
