// Physical building-form codes verified against Sinyi's public houselandtype labels (2026-10-10).
globalThis.crmSinyiBuildingType=codes=>{const map={A:'公寓',B:'電梯大樓',C:'套房',D:'透天',G:'廠房',I:'土地',L:'電梯大樓',M:'華廈',N:'透天'},types=[...new Set((Array.isArray(codes)?codes:[]).map(k=>map[k]).filter(Boolean))];return types.length===1?types[0]:'';};
// Reads rendered listing cards / embedded public listing data only. No requests or page script execution.
globalThis.crmReadListings=function(source,city){
 const txt=(e,s)=>e.querySelector(s)?.textContent.trim()||'',num=s=>s==null||s===''?null:Number.isFinite(Number(String(s).replaceAll(',','')))?Number(String(s).replaceAll(',','')):null,first=s=>num(String(s||'').replaceAll(',','').match(/[\d.]+/)?.[0]),loc=a=>{const m=a.replaceAll('臺','台').match(/^(台北市|新北市|桃園市|台中市|台南市|高雄市|基隆市|新竹市|新竹縣|苗栗縣|彰化縣|南投縣|雲林縣|嘉義市|嘉義縣|屏東縣|宜蘭縣|花蓮縣|台東縣|澎湖縣|金門縣|連江縣)(.{1,4}?區|.{1,4}?[鄉鎮市])/);return {city:m?.[1]||a.match(/^(新竹市|嘉義市)/)?.[1]||city,district:m?.[2]||''};};
 const age=s=>/個月/.test(s)?first(s)/12:/年/.test(s)?first(s):null;
 const normalize=t=>t==='電梯大廈'?'電梯大樓':t==='大樓'?'電梯大樓':t==='透天厝'?'透天':t;
 let rows=[];
 if(source==='rakuya')rows=[...document.querySelectorAll('a[href*="ehid="]')].filter(e=>e.querySelector('.card__head h2')).map(e=>{const info=txt(e,'.info__detail-info'),floor=txt(e,'.info__floor'),district=txt(e,'.info__geo--area'),geo=txt(e,'.info__geo'),tags=txt(e,'.group__tags');return {id:'rakuya:'+new URL(e.href).searchParams.get('ehid'),source,url:e.href,title:txt(e,'.card__head h2'),city,district,address:city+geo.replace(/\s+/g,' '),community:txt(e,'.info__geo--community'),price:first(txt(e,'.info__price--total')),area:first(txt(e,'.info__space')),mainArea:first(txt(e,'.info__space--main')),rooms:first(info.match(/([\d.]+)房/)?.[1]),age:age(info.match(/[\d.]+(?:年|個月)/)?.[0]||''),type:normalize(e.querySelector('.info__detail-info li')?.textContent.trim()||''),floor:num(floor.split('/')[0]),totalFloors:num(floor.split('/')[1]?.replace('樓','')),parking:/車位/.test(tags)?true:null,parkingType:/平面車位/.test(tags)?'平面':undefined,image:e.querySelector('img')?.src||'',description:tags};});
 if(source==='leju')rows=[...document.querySelectorAll('a[href^="/sales/"]')].map(a=>{const e=a.parentElement,title=a.textContent.trim().replace(/^查看物件：/,''),texts=[...e.querySelectorAll('div,span')].filter(x=>!x.children.length).map(x=>x.textContent.trim()),address=texts.find(t=>/^[^\s]{1,4}區/.test(t))||'',floor=texts.find(t=>/^[\d.-]+\/[\d]+樓$/.test(t))||'',price=texts.find(t=>/^[\d,.]+(?:億(?:[\d,.]+萬)?|萬)$/.test(t))||'',type=texts.find(t=>/^(?:店面|廠辦|公寓|大樓|華廈|套房|透天|別墅|土地)/.test(t)&&t.length<9)||'';let total=null;const pm=price.replaceAll(',','').match(/^(?:(\d+(?:\.\d+)?)億)?(?:(\d+(?:\.\d+)?)萬)?$/);if(pm)total=(Number(pm[1])||0)*10000+(Number(pm[2])||0);return {id:'leju:'+a.getAttribute('href').split('/').pop(),source,url:a.href,title,address:city+address,...loc(city+address),price:total,area:first(texts.find(t=>/^[\d.]+坪$/.test(t))),mainArea:null,rooms:first(texts.find(t=>/\d+房\d+廳/.test(t))?.match(/(\d+)房/)?.[1]),age:age(texts.find(t=>/^[\d.]+(?:年|個月)$/.test(t))||''),floor:num(floor.split('/')[0]),totalFloors:num(floor.split('/')[1]?.replace('樓','')),type:normalize(type),parking:e.querySelector('img[alt="車位"]')?true:null,community:txt(e,'a[href*="/community/"]'),image:e.querySelector('img[alt="物件照片"]')?.src||'',description:[...e.querySelectorAll('button')].map(b=>b.textContent.trim()).join(' ')};});
 if(source==='yungching')rows=[...document.querySelectorAll('.search-result-list-item > yc-ng-buy-house-card')].filter(e=>e.checkVisibility()).map(e=>{const a=e.querySelector('a[href*="house/"]'),address=txt(e,'.address'),fl=txt(e,'.floor'),tags=txt(e,'.note')+' '+txt(e,'.tag-list');return {id:'yungching:'+a?.href.match(/house\/(\d+)/)?.[1],source,url:a?.href,title:txt(e,'.caseName'),address,...loc(address),price:num(txt(e,'.price')),area:first(txt(e,'.regArea')),mainArea:/^主(?:建物)?\s*\d/.test(txt(e,'.mainArea'))?first(txt(e,'.mainArea')):null,mainAreaEvidence:/^主(?:建物)?\s*\d/.test(txt(e,'.mainArea'))?'永慶清單主建物':undefined,mainAndBalconyArea:/主\s*[+＋]\s*陽/.test(txt(e,'.mainArea'))?first(txt(e,'.mainArea')):null,community:txt(e,'.community'),parkingType:/平面/.test(txt(e,'.car'))?'平面':undefined,rooms:first(txt(e,'.room').match(/([\d.]+)房/)?.[1]),ageText:txt(e,'.case-info').match(/預售(?:屋)?|新成屋|[\d.]+年/)?.[0]||'',age:first(txt(e,'.case-info').match(/([\d.]+)年/)?.[1]),type:normalize(txt(e,'.caseType')),floorText:fl,floor:num(fl.split('/')[0]),totalFloors:num(fl.split('/')[1]?.replace('樓','')),parking:/含車位|坡道平面|坡道機械|升降平面|升降機械/.test(e.textContent)?true:null,image:e.querySelector('img')?.src||'',description:tags};});
 if(source==='sinyi'){const j=JSON.parse(document.querySelector('#__NEXT_DATA__')?.textContent||'{}');rows=(j.props?.initialReduxState?.buyReducer?.list||[]).filter(o=>!o.isOff).map(o=>({id:'sinyi:'+o.houseNo,source,url:'https://www.sinyi.com.tw/buy/house/'+o.houseNo,title:o.name,community:o.commName||'',address:o.address,...loc(o.address),price:num(o.totalPrice),area:num(o.areaBuilding),rooms:first(String(o.layout||'').match(/([\d.]+)房/)?.[1]),ageText:String(o.age??''),age:first(o.age),type:globalThis.crmSinyiBuildingType(o.houselandtypeShow||o.houselandtype),floorText:String(o.floor??''),floor:num(o.floor),totalFloors:num(o.totalfloor),parking:typeof o.isParking==='boolean'?o.isParking:null,image:o.image?.[0]||'',description:o.layout||''}));}
 if(source==='591')rows=globalThis.crmRead591(document,city);
 return [...new Map(rows.filter(p=>p.title&&(p.district||['新竹市','嘉義市'].includes(p.city))&&p.price>0&&p.url&&!p.id.endsWith('undefined')).map(p=>[p.id,p])).values()];
};

// Detail fields are distinct from source search categories.
globalThis.crmReadUnavailable=doc=>{const text=[doc.title,...[...(doc.body?.querySelectorAll('h1,h2,p,.error-message,.error-title')||[])].map(e=>e.textContent)].join(' ').replace(/\s+/g,'');return /您查詢的物件不存在|您所查詢的物件已下架|此物件已下架|此房屋已下架|此房源已下架|物件已停止銷售|您訪問的頁面不存在/.test(text)?{availability:'unavailable',availabilityReason:'原物件頁顯示已下架或不存在'}:null;};
globalThis.crmReadYCDetail=doc=>{const off=globalThis.crmReadUnavailable(doc);if(off)return off;const field=name=>{const item=[...doc.querySelectorAll('.item')].find(e=>(e.querySelector('.item-title')?.textContent||'').trim().replace(/^[・\s]+/,'')===name);return item?.querySelector('.item-detail')?.textContent.trim()||'';};const extra={};const ycFields=Object.fromEntries([...doc.querySelectorAll('.item')].map(e=>[(e.querySelector('.item-title')?.textContent||'').trim(),(e.querySelector('.item-detail')?.textContent||'').trim()]).filter(([k,v])=>k&&v));if(Object.keys(ycFields).length)extra.yungchingDetails={fields:ycFields};for(const [key,label]of [['mainArea','主建物'],['area','建物坪數'],['landArea','土地坪數']]){const m=field(label).replaceAll(',','').match(/(\d+(?:\.\d+)?)\s*坪/);if(m&&Number(m[1])>0)extra[key]=Number(m[1]);}const ageText=doc.querySelector('.info-wrapper-2 .age')?.textContent.trim().replace(/^屋齡\s*/,'')||'';if(ageText)extra.ageText=ageText;const floorText=doc.querySelector('.info-wrapper-2 .floor')?.textContent.trim()||'';if(floorText){extra.floorText=floorText;const total=floorText.split('/')[1]?.match(/^(\d+)樓$/);if(total)extra.totalFloors=Number(total[1]);}const community=field('社區').replace(/看更多社區資訊[\s\S]*$/,'').trim();if(community)extra.community=community;if(extra.mainArea)extra.mainAreaEvidence='永慶主建物';const layout=field('建物格局');for(const [key,unit]of [['rooms','房'],['halls','廳'],['bathrooms','衛']]){const m=layout.match(new RegExp('(\\d+)'+unit));if(m)extra[key]=Number(m[1]);}const parkingCount=Number(field('車位數量').match(/(\d+)個車位/)?.[1]),parkingTypes=[...doc.querySelectorAll('.item')].filter(e=>/^[・\s]*車位\s*\d+\s*$/.test(e.querySelector('.item-title')?.textContent||'')).map(e=>e.querySelector('.item-detail > div')?.textContent.trim()||'').filter(t=>/平面|機械|塔式/.test(t));const usage=field('謄本用途'),buildingType=field('型態')||doc.querySelector('.case-type')?.textContent.trim()||'';return {...extra,...(parkingTypes.length?{parking:true,parkingType:[...new Set(parkingTypes)].join('、')}:parkingCount>0?{parking:true}:/^(?:0個車位|無|無車位)$/.test(field('車位數量'))?{parking:false}:{}),...(usage?{usage,usageEvidence:'永慶謄本用途'}:{}),...(buildingType?{buildingType,type:buildingType}:{}),...(/^(住宅大樓|電梯大樓|電梯大廈)$/.test(buildingType)?{elevator:true}:{}),...(usage||buildingType?{availability:'available'}:{})};};
globalThis.crmReadSinyiDetail=(doc,id)=>{const off=globalThis.crmReadUnavailable(doc);if(off)return off;let data;try{data=JSON.parse(doc.querySelector('#__NEXT_DATA__')?.textContent||'{}').props?.initialReduxState?.buyReducer;}catch{return {};}const detail=data?.detailData,content=data?.contentData;if(String(detail?.houseNo)!==String(id))return {};const out={},usage=String(detail.detail?.purpose||'').trim();if(usage)Object.assign(out,{usage,usageEvidence:'信義謄本用途'});if(String(content?.houseNo)===String(id)){const form=globalThis.crmSinyiBuildingType(content.houselandtypeShow||content.houselandtype);if(form)Object.assign(out,{buildingType:form,type:form});
 const numeric=(value)=>value!==null&&value!==undefined&&String(value).trim()!==''&&Number.isFinite(Number(value))?Number(value):null;
 for(const [key,source]of Object.entries({area:'areaBuilding',landArea:'areaLand',price:'totalPrice',totalFloors:'floors'})){const v=numeric(content[source]);if(v!==null)out[key]=v;}
 const layout=String(content.layout||'');for(const [key,unit]of [['rooms','房'],['halls','廳'],['bathrooms','衛']]){const match=layout.match(new RegExp('(\\d+)'+unit));if(match)out[key]=Number(match[1]);}
 if(content.floor!==null&&content.floor!==undefined)out.floorText=String(content.floor);
 if(content.age){out.ageText=String(content.age);const match=out.ageText.match(/^(\d+(?:\.\d+)?)年$/);if(match)out.age=Number(match[1]);}
 out.sinyiDetails={};
 for(const key of ['houseNo','name','cityName','zipName','commId','commName','address','totalPrice','priceFirst','uniPrice','rawUniPrice','isParking','areaBuilding','areaLand','pingUsed','layout','totalLayout','age','floor','floors','areaInfo','sfside','sfdarkroom','hasmanager','monthlyFee','roomplus','hallplus','bathroomplus','openroomplus','houseFront','buildingFront','windowFront','parking','latitude','longitude','firstDisplay','images','layoutImage','layoutImage3D','vrUrl','videoUrl','cityId','zipCode','houselandtype','houselandtypeShow','landUniprice','discount','isHasBalcony','map','directionland','houseSize','parkPriceSource'])if(content[key]!==undefined)out.sinyiDetails[key]=content[key];
 out.sinyiDetails.building=detail.detail||{};out.sinyiDetails.features=detail.description||[];
 out.sinyiDetails.neighborhood=(detail.lifeInfo||[]).map(group=>({type:group.type,places:(group.info||[]).map(({title,distance,time})=>({title,distance,time}))}));
 const raw=content.areaInfo?.find(x=>x.title==='主建物')?.area;if(raw!==null&&raw!==undefined&&String(raw).trim()!==''&&Number.isFinite(Number(raw))&&Number(raw)>0)out.mainArea=Number(raw);const parking=String(content.parking||'').trim();if(parking&&/平面|機械|塔式/.test(parking)){out.parking=true;out.parkingType=parking;}else if(typeof content.isParking==='boolean')out.parking=content.isParking;}if(Object.keys(out).length)out.availability='available';return out;};
// Shared with the background worker so changing tabs/restarting a job does not reset cooldown.
globalThis.crm591Rate ||= {nextAt:0,until:0};
globalThis.crm591Fetch=async url=>{
 const rate=globalThis.crm591Rate;
 const limited=()=>Object.assign(Error('591 暫時限流，請等候冷卻後再重試'),{name:'RateLimitError',retryAt:rate.until});
 if(rate.until>Date.now())throw limited();
 const wait=Math.max(0,(rate.nextAt||0)-Date.now());if(wait)await new Promise(r=>setTimeout(r,wait));
 rate.nextAt=Date.now()+1500;
 const response=await fetch(url,{cache:'no-store',signal:AbortSignal.timeout(6000)});
 if(response.status===429){
  const header=response.headers?.get('Retry-After')||'',seconds=/^\d+$/.test(header.trim())?Number(header)*1000:Date.parse(header)-Date.now();
  rate.until=Date.now()+Math.max(60000,Number.isFinite(seconds)?seconds:0);rate.nextAt=rate.until;throw limited();
 }
 return response;
};
// Check the public URL before trusting detail data. 591 may render its fields client-side.
globalThis.crmVerifyListings=async rows=>{
 const out=[];
 for(const row of rows){
  let value={},verified=false,rateLimited=false,retryAt=0,error='原物件連結尚未確認有效，請重新搜尋';
  try{
   const response=await (row.source==='591'?globalThis.crm591Fetch(row.url):fetch(row.url,{cache:'no-store',signal:AbortSignal.timeout(6000)}));
   if([404,410].includes(response.status)){
    value={availability:'unavailable',availabilityReason:'原物件頁已失效（HTTP '+response.status+'）'};verified=true;
   }else if(response.ok){
    const doc=new DOMParser().parseFromString(await response.text(),'text/html');
    const off=globalThis.crmReadUnavailable(doc);
    const blocked=/verify you are human|checking your browser|just a moment|captcha|人機驗證|安全驗證/i.test(doc.title+' '+(doc.body?.textContent||'').slice(0,1500));
    if(off){value=off;verified=true;}
    else if(blocked){error='原站要求驗證，尚未確認連結有效';}
    else{
     value=row.source==='yungching'?globalThis.crmReadYCDetail(doc):row.source==='sinyi'?globalThis.crmReadSinyiDetail(doc,row.id.slice(6)):globalThis.crmRead591Detail(doc);
     verified=!!value.availability;
     if(row.source==='591'&&value.availability!=='unavailable'){
      const id=row.id.split(':').pop();
      // A successful generic/redirected page is insufficient: require the same detail URL
      // and a listing-specific title, then an API response for the identical listing ID.
      const sameURL=(()=>{try{const actual=new URL(response.url),expected=new URL(row.url);return actual.origin===expected.origin&&actual.pathname===expected.pathname;}catch{return false;}})();
      const listingPage=sameURL&&/\S.+\s[-–|｜]\s*591售屋網\s*$/.test(doc.title)&&!/(不存在|已下架|錯誤|找不到)/.test(doc.title);
      if(!sameURL&&response.url){verified=false;value.availability='unknown';error='原物件連結已轉向其他頁面，尚未確認有效';}
      try{
       const api=await globalThis.crm591Fetch('https://bff-house.591.com.tw/v1/web/sale/detail?id='+encodeURIComponent(id));
       if(api.ok){const details=globalThis.crmRead591API(await api.json(),id);if(details){verified=verified||!!(listingPage&&(details.usage||details.buildingType));value={...details,...value,availability:verified?'available':'unknown'};}}
      }catch(e){if(e.name==='RateLimitError')throw e;if(!verified)error='591詳細資料讀取失敗，尚未確認連結有效';}
     }
    }
   }else error='原站回應 HTTP '+response.status+'，尚未確認連結有效';
  }catch(e){if(e.name==='RateLimitError'){rateLimited=true;retryAt=e.retryAt;error=e.message;}else error=e.name==='TimeoutError'||e.name==='AbortError'?'原物件頁讀取逾時，尚未確認連結有效':'原物件頁讀取失敗，尚未確認連結有效';}
  if(!verified)value.availability='unknown';
  const at=new Date().toISOString();out.push({id:row.id,...value,detailAttemptedAt:at,detailStatus:verified?'ok':'failed',detailError:verified?'':error,...(rateLimited?{detailRateLimited:true,detailRetryAt:new Date(retryAt).toISOString()}:{}),...(verified?{detailCheckedAt:at}:{})});
 }
 return out;
};
